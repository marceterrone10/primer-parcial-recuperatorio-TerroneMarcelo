package parcialrec;


public class NaveExploracion extends Nave implements Explorable{
    private TipoMision tipoMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public void explorar() {
        System.out.println("Soy la nave de exploracion " + nombre + " y voy a iniciar la exploracion!");
    }

    @Override
    public String toString() {
        return "NaveExploracion{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + 
                ", tipoMision=" + tipoMision + '}';
    }
    
    
    
    
}
