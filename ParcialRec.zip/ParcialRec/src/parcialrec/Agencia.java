package parcialrec;

import java.util.ArrayList;


public class Agencia {
    ArrayList<Nave> naves;

    public Agencia() {
        naves = new ArrayList<>();
    }
    
    public void verificarNaveRepetida(Nave nave){
        if(naves.contains(nave)){
            throw new naveRepetidaException();
        }
    }
    
    public void agregarNave(Nave nave){
        verificarNaveRepetida(nave);
        
        if(nave!=null){
            naves.add(nave);
        }
    }
    
    public void mostrarNaves(){
        for(Nave nave: naves){
            System.out.println(nave.toString());
        }
    }
    
    public void iniciarExploracion(){
        for (Nave nave: naves){
            if(nave instanceof Explorable e){
                e.explorar();
            }
            else {
                System.out.println("La nave " + nave.getNombre() + " no tiene permitido explorar!");
            }
        }
    }
    
    
    
}
