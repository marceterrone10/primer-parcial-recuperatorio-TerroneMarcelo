package parcialrec;


public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
