package parcialrec;


public class Test {


    public static void main(String[] args) {
        //hacer uml
        Agencia a = new Agencia();
        
        NaveExploracion  nave1 = new NaveExploracion("Nave exp 1", 100, 2020, TipoMision.CARTOGRAFIA);
        NaveExploracion  nave2 = new NaveExploracion("Nave exp 2", 50, 1999, TipoMision.INVESTIGACION);
        NaveExploracion  nave3 = new NaveExploracion("Nave exp 3", 10, 2024, TipoMision.CONTACTO);
        NaveExploracion  nave4 = nave1; //igual a la nave 1
        
        Carguero carg1 = new Carguero("Galactica", 100, 2010, 300);
        Carguero carg2 = new Carguero("Carguero 2", 22, 2003, 450);
        Carguero carg3 = new Carguero("Galactica", 40, 2010, 500); //igual que carguero 1
        
        CruceroEstelar crucero1 = new CruceroEstelar("Crucerito", 2000, 2009, 1600);
        CruceroEstelar crucero2 = new CruceroEstelar("Costa crucero", 2500, 2021, 2000);
        CruceroEstelar crucero3 = new CruceroEstelar("Crucerito", 1000, 2009, 800); //igual al crucero 1
        
        System.out.println("Naves de exploracion: ");
        try{
            a.agregarNave(nave1);
            System.out.println("Se agrego la nave a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(nave2);
            System.out.println("Se agrego la nave a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(nave3);
            System.out.println("Se agrego la nave a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(nave4);
            System.out.println("Se agrego la nave a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage()); //esperable excepcion ya que se repite de nave en la agencia
        }
        
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Cargueros: ");
        try{
            a.agregarNave(carg1);
            System.out.println("Se agrego el carguero a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(carg2);
            System.out.println("Se agrego el carguero a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(carg3);
            System.out.println("Se agrego el carguero a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage()); //esperable excepcion
        }
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("Cruceros estelares: ");
        try{
            a.agregarNave(crucero1);
            System.out.println("Se agrego el crucero estelar a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(crucero2);
            System.out.println("Se agrego el crucero estelar a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage());
        }
        try{
            a.agregarNave(crucero3);
            System.out.println("Se agrego el crucero estelar a la agencia");
        
        }catch(naveRepetidaException e){
            System.out.println(e.getMessage()); //esperable excepcion
        }
        System.out.println("---------------------------------------------------------------------------------");
        
        System.out.println("Las siguientes naves se encuentran en la agencia: ");
        a.mostrarNaves();
        
        System.out.println("----------------------------------------------------------------------------------");
        
        a.iniciarExploracion();
            
    }
    
}
