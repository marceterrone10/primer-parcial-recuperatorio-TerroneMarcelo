package parcialrec;


public class CruceroEstelar extends Nave{
    private int cantPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int cantPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantPasajeros = cantPasajeros;
    }

    @Override
    public String toString() {
        return "CruceroEstelar{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + 
                ", anioLanzamiento=" + anioLanzamiento + ", cantPasajeros=" + cantPasajeros + '}';
    }

    
    
    
}
