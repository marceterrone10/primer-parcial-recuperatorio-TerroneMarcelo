package parcialrec;


public class Carguero extends Nave implements Explorable{
    private int capacidadCarga;

    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = capacidadCarga;
        verificarCarga();
    }
    
    public void verificarCarga(){
        if(capacidadCarga <= 100 && capacidadCarga > 500){
            System.out.println("La capacidad de carga no cumple con requisitos");
        }
    }

    @Override
    public void explorar() {
        System.out.println("Soy la nave carguero " + nombre + " y voy a iniciar la exploracion!");
    }

    @Override
    public String toString() {
        return "Carguero{" + "nombre=" + nombre + ", capacidadTripulacion="+ capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + 
                ", capacidadCarga=" + capacidadCarga + '}';
    }
    
    
}
