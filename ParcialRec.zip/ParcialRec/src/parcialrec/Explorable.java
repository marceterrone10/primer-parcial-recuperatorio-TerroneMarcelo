package parcialrec;


public abstract interface Explorable {
    void explorar();
}
