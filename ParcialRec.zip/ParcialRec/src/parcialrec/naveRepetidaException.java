
package parcialrec;


public class naveRepetidaException extends RuntimeException {
    private static final String MESSAGE = "La nave ya se encuentra en la agencia";
    
    public naveRepetidaException() {
        super(MESSAGE);
    }
    
}
