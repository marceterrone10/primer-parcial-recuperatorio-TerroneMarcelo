package parcialrec;

import java.util.Objects;


public abstract class Nave {
    protected String nombre;
    protected int capacidadTripulacion;
    protected int anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    @Override
    public abstract String toString();

    public String getNombre() {
        return nombre;
    }

    
    @Override
    public boolean equals(Object o){
        if(this==o){
            return true;
        }
        if(o==null || o.getClass() != this.getClass()){
            return false;
        }
        Nave nave = (Nave) o;
        return nombre.equals(nave.nombre) && anioLanzamiento == nave.anioLanzamiento;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, anioLanzamiento);
    }
    
    
    
}
